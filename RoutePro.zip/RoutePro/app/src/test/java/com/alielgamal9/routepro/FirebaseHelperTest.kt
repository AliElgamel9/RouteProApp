package com.alielgamal9.routepro

import com.alielgamal9.routepro.model.RoleType
import com.alielgamal9.routepro.model.User
import com.alielgamal9.routepro.network.FirebaseHelper
import org.hamcrest.MatcherAssert.assertThat
import org.hamcrest.Matchers.hasSize
import org.hamcrest.Matchers.nullValue
import org.hamcrest.core.Is.`is`
import org.junit.After
import org.junit.Before
import org.junit.Test

class FirebaseHelperTest {

    @Before
    fun setUp() {
    }

    @After
    fun tearDown() {
    }

    @Test
    fun fromMapToUser_givenDriverUserMap_shouldReturnDriverUser() {
        // given a map of driver data
        val user = User(100, "Alex", "Alex200@gmail.com", RoleType.DRIVER)
        val userMap = hashMapOf(
            "id" to user.id,
            "name" to user.name,
            "roleType" to user.roleType.name
        )

        // when
        val userResult = FirebaseHelper.fromMapToUser(userMap, user.email)

        // then the result should be the same user
        assertThat(userResult, `is`(user))
    }

    @Test
    fun fromMapToUser_givenSupplierUserMap_shouldReturnSupplierUser() {
        // given a map of supplier data
        val user = User(32546, "Kiro", "Kiro.kiro@yahoo.com", RoleType.SUPPLIER)
        val userMap = hashMapOf(
            "id" to user.id,
            "name" to user.name,
            "roleType" to user.roleType.name
        )

        // when
        val userResult = FirebaseHelper.fromMapToUser(userMap, user.email)

        // then the result should be the same user
        assertThat(userResult, `is`(user))
    }

    @Test
    fun fromMapToUser_givenCustomerUserMap_shouldReturnCustomerUser() {
        // given a map of customer data
        val user = User(32546, "Rana", "r.rona@youtube.com", RoleType.CUSTOMER)
        val userMap = hashMapOf(
            "id" to user.id,
            "name" to user.name,
            "roleType" to user.roleType.name
        )

        // when
        val userResult = FirebaseHelper.fromMapToUser(userMap, user.email)

        // then the result should be the same user
        assertThat(userResult, `is`(user))
    }

    @Test
    fun fromUserToMap_givenDriverUser_shouldReturnDriverUserMap() {
        // given a driver user
        val user = User(100, "Alex", "Alex200@gmail.com", RoleType.DRIVER)
        val userMap = hashMapOf(
            "id" to user.id,
            "name" to user.name,
            "roleType" to user.roleType.name
        )

        // when
        val userMapResult = FirebaseHelper.fromUserToMap(user)

        // then the result should be the same user map
        assertThat(userMapResult, `is`(userMap))
    }

    @Test
    fun fromUserToMap_givenSupplierUser_shouldReturnSupplierUserMap() {
        // given a supplier user
        val user = User(32546, "Kiro", "Kiro.kiro@yahoo.com", RoleType.SUPPLIER)
        val userMap = hashMapOf(
            "id" to user.id,
            "name" to user.name,
            "roleType" to user.roleType.name
        )

        // when
        val userMapResult = FirebaseHelper.fromUserToMap(user)

        // then the result should be the same user map
        assertThat(userMapResult, `is`(userMap))
    }

    @Test
    fun fromUserToMap_givenCustomerUser_shouldReturnCustomerUserMap() {
        // given a customer user
        val user = User(32546, "Rana", "r.rona@youtube.com", RoleType.CUSTOMER)
        val userMap = hashMapOf(
            "id" to user.id,
            "name" to user.name,
            "roleType" to user.roleType.name
        )

        // when
        val userMapResult = FirebaseHelper.fromUserToMap(user)

        // then the result should be the same user map
        assertThat(userMapResult, `is`(userMap))
    }

    @Test
    fun generateUserId_shouldGenerateDifferentIds() {
        // given
        val ids = mutableSetOf<Long>()
        for(i in 0..50) {
            ids.add(FirebaseHelper.generateUserId())
            Thread.sleep(1)
        }

        // then
        assertThat(ids, hasSize(51))
    }

    @Test
    fun validateUserName_givenValidName_shouldReturnNull() {
        // given
        val name = "AliElgamal"

        // when
        val result = FirebaseHelper.validateUserName(name)

        // then
        assertThat(result, `is`(nullValue()))
    }

    @Test
    fun validateUserName_givenNull_shouldReturnRequiredErrorCode() {
        // given
        val name = null

        // when
        val result = FirebaseHelper.validateUserName(name)

        // then
        assertThat(result, `is`(R.string.user_name_required))
    }

    @Test
    fun validateUserName_givenEmpty_shouldReturnRequiredErrorCode() {
        // given
        val name = ""

        // when
        val result = FirebaseHelper.validateUserName(name)

        // then
        assertThat(result, `is`(R.string.user_name_required))
    }

    @Test
    fun validateUserName_givenShortName_shouldReturnShortNameErrorCode() {
        // given
        val name = "ali"

        // when
        val result = FirebaseHelper.validateUserName(name)

        // then
        assertThat(result, `is`(R.string.user_name_mut_be_at_least_8_characters))
    }

    @Test
    fun validatePassword_givenValidPassword_shouldReturnNull() {
        // given
        val password = "AliElgamal123@"

        // when
        val result = FirebaseHelper.validatePassword(password)

        // then
        assertThat(result, `is`(nullValue()))
    }

    @Test
    fun validatePassword_givenNull_shouldReturnRequiredErrorCode() {
        // given
        val password = null

        // when
        val result = FirebaseHelper.validatePassword(password)

        // then
        assertThat(result, `is`(R.string.password_required))
    }

    @Test
    fun validatePassword_givenEmpty_shouldReturnRequiredErrorCode() {
        // given
        val password = ""

        // when
        val result = FirebaseHelper.validatePassword(password)

        // then
        assertThat(result, `is`(R.string.password_required))
    }

    @Test
    fun validatePassword_givenShortPassword_shouldReturnShortPasswordErrorCode() {
        // given
        val password = "A123@"

        // when
        val result = FirebaseHelper.validatePassword(password)

        // then
        assertThat(result, `is`(R.string.password_mut_be_at_least_8_characters))
    }

    @Test
    fun validatePassword_givenInValidPassword_shouldReturnPasswordPatternErrorCode() {
        // given
        val inValidPasswords = listOf("AliElgamal@", "AliElgamal123", "AliElgamal123")

        for(password in inValidPasswords){
            // when
            val result = FirebaseHelper.validatePassword(password)

            // then
            assertThat(result, `is`(R.string.password_must_consist_of_letters_numbers_and_special_characters))
        }
    }

    @Test
    fun validateEmail_givenValidEmail_shouldReturnNull() {
        // given
        val validEmail = listOf("alielgamal@gmail.com", "r.rona@yahoo.com", "b.markus@fci-cu.eg")

        for(email in validEmail){
            // when
            val result = FirebaseHelper.validateEmail(email)

            // then
            assertThat(result, `is`(nullValue()))
        }
    }

    @Test
    fun validateEmail_givenNull_shouldReturnRequiredErrorCode() {
        // given
        val email = null

        // when
        val result = FirebaseHelper.validateEmail(email)

        // then
        assertThat(result, `is`(R.string.email_required))
    }

    @Test
    fun validateEmail_givenEmptyEmail_shouldReturnRequiredErrorCode() {
        // given
        val email = ""

        // when
        val result = FirebaseHelper.validateEmail(email)

        // then
        assertThat(result, `is`(R.string.email_required))
    }

    @Test
    fun validateEmail_givenInValidEmail_shouldReturnNull() {
        // given
        val inValidEmails = listOf("http://www.google.com", "g//@gmail.com", "r.rona@",
            "@gmail.com", "r.rona$@gmail.com")

        for(email in inValidEmails) {
            // when
            val result = FirebaseHelper.validateEmail(email)

            // then
            assertThat(result, `is`(R.string.email_is_not_valid))
        }
    }

}