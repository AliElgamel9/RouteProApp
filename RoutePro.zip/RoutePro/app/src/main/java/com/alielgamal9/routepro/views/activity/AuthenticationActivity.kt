package com.alielgamal9.routepro.views.activity

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.alielgamal9.routepro.NavigationCommand
import com.alielgamal9.routepro.R
import com.alielgamal9.routepro.viewmodels.AuthenticationViewModel
import com.alielgamal9.routepro.views.fragments.LoginFragment
import com.alielgamal9.routepro.views.fragments.RegisterFragment
import org.koin.androidx.viewmodel.ext.android.viewModel

class AuthenticationActivity : AppCompatActivity() {

    private val authenticationViewModel : AuthenticationViewModel by viewModel()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_authentication)
        addFirstFragment()
        observeNavigationCommand()
    }

    private fun addFirstFragment() {
        navigateTo(LoginFragment())
    }

    private fun observeNavigationCommand() {
        authenticationViewModel.navigationCommand.observe(this) {
            navigateTo(it)
        }
    }

    private fun navigateTo(navigationCommand: NavigationCommand){
        when (navigationCommand) {
            NavigationCommand.NAVIGATE_TO_LOGIN -> navigateTo(LoginFragment())
            NavigationCommand.NAVIGATE_TO_REGISTER -> navigateTo(RegisterFragment())
            NavigationCommand.NAVIGATE_TO_MAIN_ACTIVITY -> navigateToMainActivity()
            else -> {}
        }
    }

    private fun navigateTo(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container_view, fragment)
            .commit()
    }

    private fun navigateToMainActivity() {
        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
        this.finish()
    }
}