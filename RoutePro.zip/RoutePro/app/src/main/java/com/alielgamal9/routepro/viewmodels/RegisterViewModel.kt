package com.alielgamal9.routepro.viewmodels

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.alielgamal9.routepro.NavigationCommand
import com.alielgamal9.routepro.R
import com.alielgamal9.routepro.network.AppUser
import com.alielgamal9.routepro.model.RoleType
import com.alielgamal9.routepro.network.AuthenticationListener
import com.alielgamal9.routepro.network.CredentialsResult
import com.alielgamal9.routepro.network.UserRegister

class RegisterViewModel : ViewModel() {

    val userName = MutableLiveData("")
    val password = MutableLiveData("")
    val email = MutableLiveData("")
    val roleType = MutableLiveData(RoleType.CUSTOMER)

    private var isWorking = false

    private val mUsernameErrorCode = MutableLiveData<Int?>()
    private val mPasswordErrorCode = MutableLiveData<Int?>()
    private val mEmailErrorCode = MutableLiveData<Int?>()
    private val mToastMessageCode = MutableLiveData<Int?>()
    private val mNavigationCommand = MutableLiveData<NavigationCommand>()

    val usernameErrorCode: LiveData<Int?>
        get() = mUsernameErrorCode
    val passwordErrorCode: LiveData<Int?>
        get() = mPasswordErrorCode
    val emailErrorCode: LiveData<Int?>
        get() = mEmailErrorCode
    val toastMessageCode: LiveData<Int?>
        get() = mToastMessageCode
    val navigationCommand: LiveData<NavigationCommand>
        get() = mNavigationCommand

    private val listener = object : AuthenticationListener {
        override fun onStarted() {
            mToastMessageCode.value = R.string.registering_please_wait
        }

        override fun onSuccess() {
            mToastMessageCode.value = R.string.registered_successfully
            mNavigationCommand.value = NavigationCommand.NAVIGATE_TO_LOGIN
        }

        override fun onFailure(credentialsResult: CredentialsResult) {
            mUsernameErrorCode.value = credentialsResult.usernameErrorCode
            mPasswordErrorCode.value = credentialsResult.passwordErrorCode
            mEmailErrorCode.value = credentialsResult.emailErrorCode
        }

        override fun onBusy() {
            mToastMessageCode.value = R.string.please_wait_until_last_operation_is_finished
        }

        override fun onFinish() {
            isWorking = false
        }
    }

    fun register() {
        if(isWorking){
            mToastMessageCode.value = R.string.please_wait_until_last_operation_is_finished
            return
        }
        isWorking = true
        val user = UserRegister(userName.value, password.value, email.value, roleType.value)
        AppUser.register(user, listener)
    }

    fun clearToastMessage() {
        mToastMessageCode.value = null
    }
}