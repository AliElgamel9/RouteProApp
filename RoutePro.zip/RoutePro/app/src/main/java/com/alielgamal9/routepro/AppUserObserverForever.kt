package com.alielgamal9.routepro

import androidx.lifecycle.Observer
import com.alielgamal9.routepro.network.AppUser
import com.alielgamal9.routepro.model.User

class AppUserObserverForever(private val observer: Observer<User?>) {

    init {
        startObserver()
    }

    fun startObserver() {
        AppUser.currentUserLiveData.observeForever(observer)
    }

    fun removeObserver() {
        AppUser.currentUserLiveData.removeObserver(observer)
    }
}