package com.alielgamal9.routepro.views.activity

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil.setContentView
import androidx.fragment.app.Fragment
import com.alielgamal9.routepro.NavigationCommand
import com.alielgamal9.routepro.R
import com.alielgamal9.routepro.viewmodels.MainViewModel
import com.alielgamal9.routepro.views.fragments.DriverMainFragment
import com.alielgamal9.routepro.views.fragments.LoginFragment
import com.alielgamal9.routepro.views.fragments.RegisterFragment
import org.koin.androidx.viewmodel.ext.android.viewModel

class MainActivity : AppCompatActivity() {

    private val mainViewModel : MainViewModel by viewModel()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_authentication)
        observeNavigationCommand()
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when(item.itemId) {
            R.id.logout -> {
                mainViewModel.logout()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun observeNavigationCommand() {
        mainViewModel.navigationCommand.observe(this) {
            navigateTo(it)
        }
    }

    private fun navigateTo(navigationCommand: NavigationCommand){
        when (navigationCommand) {
            NavigationCommand.NAVIGATE_TO_MAIN_CUSTOMER -> navigateTo(LoginFragment())
            NavigationCommand.NAVIGATE_TO_MAIN_DRIVER -> navigateTo(DriverMainFragment())
            NavigationCommand.NAVIGATE_TO_MAIN_SUPPLIER -> navigateTo(RegisterFragment())
            NavigationCommand.NAVIGATE_TO_LOGIN -> navigateToAuthenticationActivity()
            else -> {}
        }
    }

    private fun navigateTo(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container_view, fragment)
            .commit()
    }

    private fun navigateToAuthenticationActivity() {
        val intent = Intent(this, AuthenticationActivity::class.java)
        startActivity(intent)
        this.finish()
    }
}