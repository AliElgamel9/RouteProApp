package com.alielgamal9.routepro.utils

import android.content.Context
import android.view.View
import android.widget.AdapterView
import android.widget.RadioGroup
import android.widget.Spinner
import androidx.appcompat.widget.AppCompatSpinner
import androidx.databinding.BindingAdapter
import androidx.databinding.InverseBindingAdapter
import androidx.databinding.InverseBindingListener
import androidx.databinding.InverseMethod
import com.alielgamal9.routepro.model.RoleType

object BindingUtils {

    @JvmStatic
    fun getErrorCodeMessage(errorCode: Int?, context: Context): String {
        if(errorCode == null) return ""
        return context.getString(errorCode)
    }

    @JvmStatic
    fun positionToRoleType(position: Int) : RoleType {
        return RoleType.values()[position]
    }

    @InverseMethod("positionToRoleType")
    @JvmStatic
    fun roleTypeToPosition(roleType: RoleType) : Int {
        return roleType.ordinal
    }
}