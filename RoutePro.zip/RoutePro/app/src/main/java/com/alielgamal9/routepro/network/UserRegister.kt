package com.alielgamal9.routepro.network

import com.alielgamal9.routepro.model.RoleType

data class UserRegister(val name: String?, val password: String?, val email: String?, val roleType: RoleType?)