package com.alielgamal9.routepro.views.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import com.alielgamal9.routepro.NavigationCommand
import com.alielgamal9.routepro.R
import com.alielgamal9.routepro.databinding.FragmentRegisterBinding
import com.alielgamal9.routepro.viewmodels.AuthenticationViewModel
import com.alielgamal9.routepro.viewmodels.RegisterViewModel
import org.koin.androidx.viewmodel.ext.android.activityViewModel
import org.koin.androidx.viewmodel.ext.android.viewModel

class RegisterFragment : Fragment() {

    private val registerViewModel : RegisterViewModel by viewModel()
    private val authenticationViewModel : AuthenticationViewModel by activityViewModel()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val binding = DataBindingUtil.inflate<FragmentRegisterBinding>(inflater, R.layout.fragment_register, container, false)
        binding.lifecycleOwner = this
        binding.registerViewModel = registerViewModel
        binding.authenticationViewModel = authenticationViewModel
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        observeToastMessage()
        observerNavigationCommands()
    }

    private fun observeToastMessage() {
        registerViewModel.toastMessageCode.observe(viewLifecycleOwner) {
            if (it != null) {
                Toast.makeText(requireContext(), getString(it), Toast.LENGTH_SHORT).show()
                registerViewModel.clearToastMessage()
            }
        }
    }

    private fun observerNavigationCommands(){
        registerViewModel.navigationCommand.observe(viewLifecycleOwner){
            when(it){
                NavigationCommand.NAVIGATE_TO_LOGIN -> authenticationViewModel.navigateToLogin()
                else -> {}
            }
        }
    }
}