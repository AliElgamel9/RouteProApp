package com.alielgamal9.routepro.viewmodels

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.alielgamal9.routepro.R
import com.alielgamal9.routepro.network.AppUser
import com.alielgamal9.routepro.network.AuthenticationListener
import com.alielgamal9.routepro.network.CredentialsResult
import com.alielgamal9.routepro.network.UserLogin

class LoginViewModel : ViewModel() {

    val email = MutableLiveData("")
    val password = MutableLiveData("")

    private var isWorking = false

    private val mEmailErrorCode = MutableLiveData<Int?>()
    private val mPasswordErrorCode = MutableLiveData<Int?>()
    private val mLoginErrorCode = MutableLiveData<Int?>()
    private val mToastMessageCode = MutableLiveData<Int?>()

    val emailErrorCode: LiveData<Int?>
        get() = mEmailErrorCode
    val passwordErrorCode: LiveData<Int?>
        get() = mPasswordErrorCode
    val loginErrorCode: LiveData<Int?>
        get() = mLoginErrorCode
    val toastMessageCode: LiveData<Int?>
        get() = mToastMessageCode

    private val listener = object : AuthenticationListener {
        override fun onStarted() {
            mToastMessageCode.value = R.string.logging_please_wait
        }

        override fun onSuccess() {
            // pass
        }

        override fun onFailure(credentialsResult: CredentialsResult) {
            mLoginErrorCode.value = credentialsResult.operationErrorCode
            mEmailErrorCode.value = credentialsResult.emailErrorCode
            mPasswordErrorCode.value = credentialsResult.passwordErrorCode
        }

        override fun onBusy() {
            mToastMessageCode.value = R.string.please_wait_until_last_operation_is_finished
        }

        override fun onFinish() {
            isWorking = false
        }
    }

    fun login() {
        if(isWorking) {
            mToastMessageCode.value = R.string.please_wait_until_last_operation_is_finished
            return
        }
        isWorking = true
        val userLogin = UserLogin(email.value, password.value)
        AppUser.login(userLogin, listener)
    }

    fun clearToastMessage() {
        mToastMessageCode.value = null
    }
}