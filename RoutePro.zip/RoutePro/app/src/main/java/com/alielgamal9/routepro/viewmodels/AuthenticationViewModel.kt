package com.alielgamal9.routepro.viewmodels

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.alielgamal9.routepro.AppUserObserverForever
import com.alielgamal9.routepro.NavigationCommand
import com.alielgamal9.routepro.model.User

class AuthenticationViewModel : ViewModel() {

    private val mNavigationCommand = MutableLiveData<NavigationCommand>()

    private val appUserObserver = AppUserObserverForever{ userIsUpdated(it) }

    val navigationCommand: LiveData<NavigationCommand>
        get() = mNavigationCommand

    override fun onCleared() {
        super.onCleared()
        appUserObserver.removeObserver()
    }

    fun navigateToLogin() {
        mNavigationCommand.value = NavigationCommand.NAVIGATE_TO_LOGIN
    }

    fun navigateToRegister() {
        mNavigationCommand.value = NavigationCommand.NAVIGATE_TO_REGISTER
    }

    private fun userIsUpdated(user: User?) {
        if(user != null)
            navigateToMainActivity()
    }

    private fun navigateToMainActivity() {
        mNavigationCommand.value = NavigationCommand.NAVIGATE_TO_MAIN_ACTIVITY
    }
}