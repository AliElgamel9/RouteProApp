package com.alielgamal9.routepro.views.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import com.alielgamal9.routepro.R
import com.alielgamal9.routepro.databinding.FragmentDriverMainBinding
import com.alielgamal9.routepro.viewmodels.DriverMainViewModel
import org.koin.androidx.viewmodel.ext.android.viewModel

class DriverMainFragment : Fragment() {

    private val viewModel : DriverMainViewModel by viewModel()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val view = DataBindingUtil.inflate<FragmentDriverMainBinding>(inflater,
            R.layout.fragment_driver_main, container, false)
        view.lifecycleOwner = this
        view.driverMainViewModel = viewModel
        return view.root
    }

}