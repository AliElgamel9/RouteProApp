package com.alielgamal9.routepro.viewmodels

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.alielgamal9.routepro.AppUserObserverForever
import com.alielgamal9.routepro.NavigationCommand
import com.alielgamal9.routepro.model.RoleType
import com.alielgamal9.routepro.model.User
import com.alielgamal9.routepro.network.AppUser

class MainViewModel : ViewModel() {

    private val mNavigationCommand = MutableLiveData<NavigationCommand>()

    private val appUserObserver = AppUserObserverForever{ userIsUpdated(it) }

    val navigationCommand: LiveData<NavigationCommand>
        get() = mNavigationCommand

    fun logout() {
        AppUser.logout()
    }

    override fun onCleared() {
        super.onCleared()
        appUserObserver.removeObserver()
    }

    private fun userIsUpdated(user: User?) {
        if(user == null)
            navigateToLogin()
        else
            navigateToMainOf(user)
    }

    private fun navigateToLogin() {
        mNavigationCommand.value = NavigationCommand.NAVIGATE_TO_LOGIN
    }

    private fun navigateToMainOf(user: User) {
        when(user.roleType){
            RoleType.DRIVER -> mNavigationCommand.value = NavigationCommand.NAVIGATE_TO_MAIN_DRIVER
            RoleType.SUPPLIER -> mNavigationCommand.value = NavigationCommand.NAVIGATE_TO_MAIN_SUPPLIER
            RoleType.CUSTOMER -> mNavigationCommand.value = NavigationCommand.NAVIGATE_TO_MAIN_CUSTOMER
        }
    }
}