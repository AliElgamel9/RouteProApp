package com.alielgamal9.routepro.network

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.alielgamal9.routepro.R
import com.alielgamal9.routepro.model.User
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase

object AppUser {

    private val TAG = AppUser::class.java.simpleName

    private val mCurrentUserLiveData = MutableLiveData<User?>()

    private var authStatus = AuthStatus.FREE

    private val auth = Firebase.auth

    val currentUserLiveData: LiveData<User?>
        get() = mCurrentUserLiveData

    val currentUser: User?
        get() = mCurrentUserLiveData.value

    init {
        observeFirebaseUser()
    }

    fun isAuthBusy(): Boolean{
        return authStatus != AuthStatus.FREE
    }

    fun isAuthRegistering(): Boolean{
        return authStatus == AuthStatus.REGISTERING
    }

    fun logout(){
        auth.signOut()
    }

    private fun observeFirebaseUser(){
        Firebase.auth.addAuthStateListener {
            if (isAuthRegistering())
                return@addAuthStateListener
            onAuthUserChange()
        }
    }

    private fun onAuthUserChange(){
        val authUser = auth.currentUser
        if (authUser != null) onLogin()
        else onLogout()
    }

    private fun onLogin(){
        val authUser = auth.currentUser ?: return
        FirebaseHelper.getUserDataFromFirebase(authUser.email!!) { user ->
            if(user == null)
                Log.e(TAG, "missed add user to firestore")
            else
                mCurrentUserLiveData.value = user
        }
    }

    private fun onLogout(){
        mCurrentUserLiveData.value = null
    }

    fun login(userLogin: UserLogin, listener: AuthenticationListener) {
        if(isAuthBusy()){
            listener.onBusy()
            listener.onFinish()
            return
        }

        authStatus = AuthStatus.LOGGING_IN
        listener.onStarted()

        val credentialsResult = getLoginCredentialsResult(userLogin)
        if(credentialsResult.isAnyError()){
            listener.onFailure(credentialsResult)
            listener.onFinish()
            authFinished()
            return
        }
        val auth = Firebase.auth
        auth.signInWithEmailAndPassword(userLogin.email!!, userLogin.password!!)
            .addOnCompleteListener { task ->
                if (task.isSuccessful)
                    onLoginSuccess(listener)
                else
                    onLoginFailure(listener)
            }
    }

    fun getLoginCredentialsResult(userLogin: UserLogin) : CredentialsResult{
        val emailErrorCode = validateEmailLogin(userLogin.email)
        val passwordErrorCode = validatePasswordLogin(userLogin.password)
        return CredentialsResult(emailErrorCode = emailErrorCode,
            passwordErrorCode = passwordErrorCode)
    }

    fun validateEmailLogin(email: String?) : Int?{
        return if(email.isNullOrEmpty())
            R.string.email_required
        else
            null
    }

    fun validatePasswordLogin(password: String?) : Int?{
        return if(password.isNullOrEmpty())
            R.string.password_required
        else
            null
    }

    fun onLoginSuccess(listener: AuthenticationListener){
        listener.onSuccess()
        listener.onFinish()
        authFinished()
    }

    fun onLoginFailure(listener: AuthenticationListener){
        val credentialsResult = CredentialsResult(
            operationErrorCode = R.string.user_name_or_password_is_incorrect)
        listener.onFailure(credentialsResult)
        listener.onFinish()
        authFinished()
    }

    fun register(user: UserRegister, listener: AuthenticationListener){
        if(isAuthBusy()){
            listener.onBusy()
            listener.onFinish()
            return
        }

        authStatus = AuthStatus.REGISTERING
        listener.onStarted()

        val credentialsResult = getRegisterCredentialsResult(user)
        if(credentialsResult.isAnyError()){
            listener.onFailure(credentialsResult)
            listener.onFinish()
            authFinished()
            return
        }

        auth.createUserWithEmailAndPassword(user.email!!, user.password!!)
            .addOnCompleteListener { task ->
                if (task.isSuccessful)
                    onRegisterSuccess(user, listener)
                else
                    onRegisterFailed(listener)
            }
    }

    fun getRegisterCredentialsResult(user: UserRegister) : CredentialsResult{
        val usernameErrorCode = FirebaseHelper.validateUserName(user.name)
        val passwordErrorCode = FirebaseHelper.validatePassword(user.password)
        val emailErrorCode = FirebaseHelper.validateEmail(user.email)
        return CredentialsResult(usernameErrorCode, passwordErrorCode, emailErrorCode)
    }

    private fun onRegisterSuccess(user: UserRegister, listener: AuthenticationListener){
        auth.signOut()
        FirebaseHelper.addUserRegisterDataToFirebase(user) {
            listener.onSuccess()
            listener.onFinish()
            authFinished()
        }
    }

    private fun onRegisterFailed(listener: AuthenticationListener){
        val credentialsResult = CredentialsResult(emailErrorCode = R.string.email_is_already_registered)
        listener.onFailure(credentialsResult)
        listener.onFinish()
        authFinished()
    }

    private fun authFinished(){
        authStatus = AuthStatus.FREE
    }
}