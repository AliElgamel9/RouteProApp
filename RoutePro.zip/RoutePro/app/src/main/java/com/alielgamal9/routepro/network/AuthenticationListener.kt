package com.alielgamal9.routepro.network

interface AuthenticationListener {
    fun onStarted()
    fun onSuccess()
    fun onFailure(credentialsResult: CredentialsResult)
    fun onBusy()
    fun onFinish()
}