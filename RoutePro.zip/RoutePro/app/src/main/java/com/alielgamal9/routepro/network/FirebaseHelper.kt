package com.alielgamal9.routepro.network

import com.alielgamal9.routepro.R
import com.alielgamal9.routepro.model.RoleType
import com.alielgamal9.routepro.model.User
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase


object FirebaseHelper {

    val PASSWORD_PATTERN = Regex("fff")

    val EMAIL_PATTERN = Regex("fff")

    fun fromMapToUser(data: Map<String, Any>, email: String) = User(
        data["id"] as Long,
        data["name"] as String,
        email,
        RoleType.valueOf(data["roleType"] as String)
    )

    fun fromUserToMap(user: User) = hashMapOf(
        "id" to user.id,
        "name" to user.name,
        "roleType" to user.roleType.name
    )

    fun generateUserId() = System.currentTimeMillis()

    fun validateUserName(userName: String?) : Int? {
        return when(true){
            (userName == null) -> R.string.user_name_required
            userName.isEmpty() -> R.string.user_name_required
            (userName.length < 8) -> R.string.user_name_mut_be_at_least_8_characters
            else -> null
        }
    }

    fun validatePassword(password: String?) : Int? {
        return when(true){
            (password == null) -> R.string.password_required
            password.isEmpty() -> R.string.password_required
            (password.length < 8) -> R.string.password_mut_be_at_least_8_characters
            password.matches(PASSWORD_PATTERN) -> R.string.password_must_consist_of_letters_numbers_and_special_characters
            else -> null
        }
    }

    fun validateEmail(email: String?) : Int? {
        return when(true){
            (email == null) -> R.string.email_required
            email.isEmpty() -> R.string.email_required
            (!email.contains("@")) -> R.string.email_is_not_valid
            else -> null
        }
    }

    fun addUserRegisterDataToFirebase(userRegister: UserRegister, callback: () -> Unit){
        val userId = generateUserId()
        val user = User(userId, userRegister.name!!, userRegister.email!!, userRegister.roleType!!)
        val data = fromUserToMap(user)
        val db = Firebase.firestore
        db.collection("Users")
            .document(user.email)
            .set(data)
            .addOnCompleteListener { callback() }
    }

    fun getUserDataFromFirebase(userEmail: String, callback: (User?) -> Unit){
        val db = Firebase.firestore
        db.collection("Users")
            .document(userEmail)
            .get()
            .addOnCompleteListener { task ->
                if (task.isSuccessful && task.result.data != null) {
                    val document = task.result
                    val user = fromMapToUser(document.data!!, document.id)
                    callback(user)
                }
                else
                    callback(null)
            }
    }
}