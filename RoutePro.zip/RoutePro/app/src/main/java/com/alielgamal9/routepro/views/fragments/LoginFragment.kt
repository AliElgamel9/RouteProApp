package com.alielgamal9.routepro.views.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import com.alielgamal9.routepro.R
import com.alielgamal9.routepro.databinding.FragmentLoginBinding
import com.alielgamal9.routepro.viewmodels.AuthenticationViewModel
import com.alielgamal9.routepro.viewmodels.LoginViewModel
import org.koin.androidx.viewmodel.ext.android.activityViewModel
import org.koin.androidx.viewmodel.ext.android.viewModel

class LoginFragment : Fragment() {

    private val loginViewModel : LoginViewModel by viewModel()
    private val authenticationViewModel : AuthenticationViewModel by activityViewModel()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val binding = DataBindingUtil.inflate<FragmentLoginBinding>(inflater, R.layout.fragment_login, container, false)
        binding.lifecycleOwner = this
        binding.loginViewModel = loginViewModel
        binding.authenticationViewModel = authenticationViewModel
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        observeToastMessage()
    }

    private fun observeToastMessage() {
        loginViewModel.toastMessageCode.observe(viewLifecycleOwner) {
            if (it != null) {
                Toast.makeText(requireContext(), getString(it), Toast.LENGTH_SHORT).show()
                loginViewModel.clearToastMessage()
            }
        }
    }
}