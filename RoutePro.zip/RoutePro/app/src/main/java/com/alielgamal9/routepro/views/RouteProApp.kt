package com.alielgamal9.routepro.views

import android.app.Application
import com.alielgamal9.routepro.viewmodels.AuthenticationViewModel
import com.alielgamal9.routepro.viewmodels.DriverMainViewModel
import com.alielgamal9.routepro.viewmodels.LoginViewModel
import com.alielgamal9.routepro.viewmodels.MainViewModel
import com.alielgamal9.routepro.viewmodels.RegisterViewModel
import org.koin.android.ext.koin.androidContext
import org.koin.android.ext.koin.androidLogger
import org.koin.androidx.viewmodel.dsl.viewModel
import org.koin.core.context.startKoin
import org.koin.dsl.module

class RouteProApp : Application() {

    override fun onCreate() {
        super.onCreate()

        startKoin{
            androidLogger()
            androidContext(this@RouteProApp)
            modules(myModule)
        }
    }

    private val myModule = module {
        viewModel { AuthenticationViewModel() }
        viewModel { LoginViewModel() }
        viewModel { RegisterViewModel() }
        viewModel { MainViewModel() }
        viewModel { DriverMainViewModel() }
    }
}