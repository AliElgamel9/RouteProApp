package com.alielgamal9.routepro.viewmodels

import androidx.lifecycle.ViewModel
import com.alielgamal9.routepro.network.AppUser
import com.alielgamal9.routepro.model.User

class DriverMainViewModel : ViewModel() {
    val currentUser : User = AppUser.currentUser!!
}