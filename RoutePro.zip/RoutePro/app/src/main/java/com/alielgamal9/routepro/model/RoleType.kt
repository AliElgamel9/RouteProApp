package com.alielgamal9.routepro.model

enum class RoleType {
    CUSTOMER,
    DRIVER,
    SUPPLIER
}