package com.alielgamal9.routepro.network

class CredentialsResult(val usernameErrorCode: Int?=null,
                        val passwordErrorCode: Int?=null,
                        val emailErrorCode: Int?=null,
                        val operationErrorCode: Int?=null) {

    fun isNoError(): Boolean = !isAnyError()

    fun isAnyError(): Boolean {
        return usernameErrorCode != null || passwordErrorCode != null || emailErrorCode != null
    }
}