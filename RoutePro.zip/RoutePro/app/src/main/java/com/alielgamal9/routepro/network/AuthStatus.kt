package com.alielgamal9.routepro.network

enum class AuthStatus {
    REGISTERING,
    LOGGING_IN,
    FREE
}