package com.alielgamal9.routepro.network

data class UserLogin(val email: String?, val password: String?)